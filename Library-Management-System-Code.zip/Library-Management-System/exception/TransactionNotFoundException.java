package exception;

public class TransactionNotFoundException extends LibraryException {
    private static final long serialVersionUID = 1L;

    public TransactionNotFoundException(String message) {
        super(message);
    }
}
