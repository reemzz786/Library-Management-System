package exception;

/** Base class for all custom exceptions of the Library Management System. */
public class LibraryException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    public LibraryException(String message) {
        super(message);
    }
}
