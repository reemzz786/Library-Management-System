package exception;

public class DuplicateEntryException extends LibraryException {
    private static final long serialVersionUID = 1L;

    public DuplicateEntryException(String message) {
        super(message);
    }
}
