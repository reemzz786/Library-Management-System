package main;

import exception.LibraryException;
import java.time.LocalDate;
import java.util.NoSuchElementException;
import java.util.Scanner;
import service.Library;
import util.ValidationUtil;

/** Entry point: menu-driven console interface of the Library Management System. */
public class LibraryManagementSystem {

    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        Library library = new Library();

        while (true) {
            printMenu();
            int choice = readInt("Choose an option: ", 1, 6);
            try {
                switch (choice) {
                    case 1:
                        addBook(library);
                        break;
                    case 2:
                        addMember(library);
                        break;
                    case 3:
                        borrowBook(library);
                        break;
                    case 4:
                        returnBook(library);
                        break;
                    case 5:
                        library.displayAvailableBooks();
                        break;
                    case 6:
                        System.out.println("Thank you for using the Library Management System."
                                + " Goodbye!");
                        scanner.close();
                        return;
                }
            } catch (LibraryException e) {
                System.out.println("Error: " + e.getMessage() + "\n");
            } catch (NoSuchElementException e) {
                System.out.println("Input ended. Exiting the application.");
                return;
            } catch (Exception e) {
                System.out.println("Unexpected error: " + e.getMessage() + "\n");
            }
        }
    }

    private static void printMenu() {
        System.out.println("=========================================");
        System.out.println("       LIBRARY MANAGEMENT SYSTEM         ");
        System.out.println("=========================================");
        System.out.println("1. Add Book");
        System.out.println("2. Add Member");
        System.out.println("3. Borrow Book");
        System.out.println("4. Return Book");
        System.out.println("5. Display Available Books");
        System.out.println("6. Exit");
    }

    // ---------------- menu actions ----------------

    private static void addBook(Library library) {
        String bookId = readId("Enter Book ID: ");
        String title = readNonEmpty("Enter Title: ");
        String authorName = readNonEmpty("Enter Author Name: ");
        String country = readNonEmpty("Enter Author Country: ");
        int copies = readInt("Enter Number of Copies: ", 1, 1000);
        library.addBook(bookId, title, authorName, country, copies);
        System.out.println("Book added successfully!\n");
    }

    private static void addMember(Library library) {
        String memberId = readId("Enter Member ID: ");
        String name = readNonEmpty("Enter Name: ");
        String email = readEmail("Enter Email: ");
        String phone = readPhone("Enter Phone (10 digits): ");
        int type = readInt("Member Type (1 for Regular, 2 for Premium): ", 1, 2);
        library.addMember(type == 2, memberId, name, email, phone);
        System.out.println("Member added successfully!\n");
    }

    private static void borrowBook(Library library) {
        String memberId = readId("Enter Member ID: ");
        String bookId = readId("Enter Book ID: ");
        LocalDate borrowDate =
                readDate("Enter Borrow Date (dd-MM-yyyy) or press Enter for today: ");
        library.borrowBook(memberId, bookId, borrowDate);
    }

    private static void returnBook(Library library) {
        String txnId = readId("Enter Borrow Transaction ID: ");
        LocalDate returnDate =
                readDate("Enter Return Date (dd-MM-yyyy) or press Enter for today: ");
        library.returnBook(txnId, returnDate);
    }

    // ------------- validated input helpers (repeat until the input is valid) -------------

    private static String readNonEmpty(String prompt) {
        while (true) {
            System.out.print(prompt);
            String text = scanner.nextLine();
            if (ValidationUtil.isNotEmpty(text)) {
                return text.trim();
            }
            System.out.println("Input cannot be empty. Please try again.");
        }
    }

    private static String readId(String prompt) {
        return readNonEmpty(prompt).toUpperCase();
    }

    private static int readInt(String prompt, int min, int max) {
        while (true) {
            System.out.print(prompt);
            try {
                int value = Integer.parseInt(scanner.nextLine().trim());
                if (value >= min && value <= max) {
                    return value;
                }
                System.out.println("Please enter a number between " + min + " and " + max + ".");
            } catch (NumberFormatException e) {
                System.out.println("Invalid input! Please enter a whole number.");
            }
        }
    }

    private static String readEmail(String prompt) {
        while (true) {
            String email = readNonEmpty(prompt);
            if (ValidationUtil.isValidEmail(email)) {
                return email;
            }
            System.out.println("Invalid email format. Example: name@example.com");
        }
    }

    private static String readPhone(String prompt) {
        while (true) {
            String phone = readNonEmpty(prompt);
            if (ValidationUtil.isValidPhone(phone)) {
                return phone;
            }
            System.out.println("Invalid phone number. Enter exactly 10 digits.");
        }
    }

    /** Blank input means today's date. */
    private static LocalDate readDate(String prompt) {
        while (true) {
            System.out.print(prompt);
            String text = scanner.nextLine();
            if (!ValidationUtil.isNotEmpty(text)) {
                return LocalDate.now();
            }
            LocalDate date = ValidationUtil.parseDate(text);
            if (date != null) {
                return date;
            }
            System.out.println("Invalid date. Use the format dd-MM-yyyy (e.g., 01-11-2026).");
        }
    }
}
