# Library Management System (Specification No. 2)

**Course:** 23CSR306 Java Programming - Assignment II (OOP Mini Project)
**Student:** REEMA FARHANA J
**Register Number:** 717825F144

## Problem Statement
A Java console application that manages books, members, borrowing and returns, keeping
accurate track of book availability, member limits and late-return fines.

## Package Structure
| Package     | Classes |
|-------------|---------|
| `model`     | `Author`, `Book`, `Member`, `PremiumMember`, `BorrowTransaction`, `ReturnTransaction` |
| `service`   | `Library` |
| `exception` | `LibraryException` (base) + 7 custom exceptions |
| `util`      | `ValidationUtil` |
| `main`      | `LibraryManagementSystem` (menu-driven entry point) |

## OOP Concepts
- **Encapsulation:** private fields with getters; stock changes only through `Book` methods.
- **Inheritance:** `Member` -> `PremiumMember`; all custom exceptions extend `LibraryException`.
- **Aggregation:** `Book` has an `Author`; transactions hold `Member`/`Book`; `Library` holds lists of books, members and transactions.
- **Polymorphism:** `PremiumMember` overrides `getMemberType()`, `getMaxBooks()`, `getLoanDays()`, `getFinePerDay()`.

## Business Rules
| Rule | Implementation |
|------|----------------|
| 1. Borrow only if available | `BookNotAvailableException` when copies = 0 |
| 2. Stock updates on borrow/return | `Book.decreaseStock()` / `increaseStock()`; shown on every receipt |
| 3. Premium benefits | Regular: 3 books, 14 days. Premium: 6 books, 30 days |
| 4. Late fine | `late days x fine per day` (Regular Rs.5, Premium Rs.2) |
| 5. Transactions link to books | `BorrowTransaction` / `ReturnTransaction` reference the `Book` and `Member` |

## Menu
1. Add Book  2. Add Member  3. Borrow Book  4. Return Book  5. Display Available Books  6. Exit

Dates use the format `dd-MM-yyyy`. Press Enter at a date prompt to use today's date.

## Compile and Run
```
javac -d bin exception/*.java util/*.java model/*.java service/*.java main/*.java
java -cp bin main.LibraryManagementSystem
```
(Requires JDK 8 or later.)
