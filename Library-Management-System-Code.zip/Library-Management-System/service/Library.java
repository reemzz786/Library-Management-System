package service;

import exception.*;
import java.time.LocalDate;
import java.util.*;
import model.*;

/** Central class of the system. It HAS lists of books, members and transactions (aggregation). */
public class Library {
    private Map<String, Book> books = new LinkedHashMap<>();
    private Map<String, Member> members = new LinkedHashMap<>();
    private Map<String, Author> authors = new HashMap<>();
    private Map<String, BorrowTransaction> borrowTransactions = new LinkedHashMap<>();
    private List<ReturnTransaction> returnTransactions = new ArrayList<>();
    private int borrowCounter = 1000;
    private int returnCounter = 2000;

    public void addBook(String bookId, String title, String authorName,
                        String country, int copies) {
        if (books.containsKey(bookId)) {
            throw new DuplicateEntryException("Book ID already exists: " + bookId);
        }
        // Reuse the Author object if the same author already exists
        Author author = authors.computeIfAbsent(authorName.toLowerCase(),
                k -> new Author(authorName, country));
        books.put(bookId, new Book(bookId, title, author, copies));
    }

    public void addMember(boolean premium, String memberId, String name,
                          String email, String phone) {
        if (members.containsKey(memberId)) {
            throw new DuplicateEntryException("Member ID already exists: " + memberId);
        }
        Member member = premium ? new PremiumMember(memberId, name, email, phone)
                                : new Member(memberId, name, email, phone);
        members.put(memberId, member);
    }

    public Book getBook(String bookId) {
        Book book = books.get(bookId);
        if (book == null) throw new BookNotFoundException("Book ID not found: " + bookId);
        return book;
    }

    public Member getMember(String memberId) {
        Member member = members.get(memberId);
        if (member == null) throw new MemberNotFoundException("Member ID not found: " + memberId);
        return member;
    }

    public BorrowTransaction getBorrowTransaction(String txnId) {
        BorrowTransaction txn = borrowTransactions.get(txnId);
        if (txn == null) {
            throw new TransactionNotFoundException("Borrow transaction not found: " + txnId);
        }
        return txn;
    }

    public void borrowBook(String memberId, String bookId, LocalDate borrowDate) {
        Member member = getMember(memberId);
        Book book = getBook(bookId);
        BorrowTransaction txn = new BorrowTransaction("BRW" + (borrowCounter + 1),
                member, book, borrowDate);
        txn.execute();                                   // throws if rules are violated
        borrowCounter++;                                 // used only after a successful borrow
        borrowTransactions.put(txn.getTransactionId(), txn);
    }

    public void returnBook(String borrowTxnId, LocalDate returnDate) {
        BorrowTransaction borrowTxn = getBorrowTransaction(borrowTxnId);
        ReturnTransaction returnTxn = new ReturnTransaction("RET" + (returnCounter + 1),
                borrowTxn, returnDate);
        returnTxn.execute();
        returnCounter++;
        returnTransactions.add(returnTxn);
    }

    public void displayAvailableBooks() {
        System.out.println("\n=================== AVAILABLE BOOKS ===================");
        System.out.printf("%-8s %-30s %-20s %s%n", "Book ID", "Title", "Author", "Stock");
        System.out.println("-------------------------------------------------------");
        boolean found = false;
        for (Book b : books.values()) {
            if (b.isAvailable()) {
                System.out.printf("%-8s %-30s %-20s %d/%d%n", b.getBookId(), b.getTitle(),
                        b.getAuthor().getName(), b.getAvailableCopies(), b.getTotalCopies());
                found = true;
            }
        }
        if (!found) {
            System.out.println("No books are currently available.");
        }
        System.out.println("=======================================================\n");
    }
}
