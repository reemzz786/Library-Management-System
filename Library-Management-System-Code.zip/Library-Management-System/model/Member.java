package model;

/** A regular library member. PremiumMember extends this class. */
public class Member {
    private String memberId;
    private String name;
    private String email;
    private String phone;
    private int borrowedCount;      // books currently held by the member

    public Member(String memberId, String name, String email, String phone) {
        this.memberId = memberId;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.borrowedCount = 0;
    }

    public String getMemberId() { return memberId; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public String getPhone() { return phone; }
    public int getBorrowedCount() { return borrowedCount; }

    // These values are overridden by PremiumMember (polymorphism)
    public String getMemberType() { return "Regular"; }
    public int getMaxBooks() { return 3; }
    public int getLoanDays() { return 14; }
    public double getFinePerDay() { return 5.0; }

    public boolean canBorrow() {
        return borrowedCount < getMaxBooks();
    }

    public void incrementBorrowed() { borrowedCount++; }

    public void decrementBorrowed() {
        if (borrowedCount > 0) {
            borrowedCount--;
        }
    }

    public void displayMemberDetails() {
        System.out.printf("%-8s | %-18s | %-9s | Books: %d/%d | Loan: %d days | "
                        + "Fine: Rs.%.2f/day%n",
                memberId, name, getMemberType(), borrowedCount, getMaxBooks(),
                getLoanDays(), getFinePerDay());
    }
}
