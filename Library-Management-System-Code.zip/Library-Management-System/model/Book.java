package model;

import exception.BookNotAvailableException;

/** A book in the library. Keeps track of total and available copies. */
public class Book {
    private String bookId;
    private String title;
    private Author author;          // aggregation: Book has an Author
    private int totalCopies;
    private int availableCopies;

    public Book(String bookId, String title, Author author, int totalCopies) {
        this.bookId = bookId;
        this.title = title;
        this.author = author;
        this.totalCopies = totalCopies;
        this.availableCopies = totalCopies;
    }

    public String getBookId() { return bookId; }
    public String getTitle() { return title; }
    public Author getAuthor() { return author; }
    public int getTotalCopies() { return totalCopies; }
    public int getAvailableCopies() { return availableCopies; }

    public boolean isAvailable() {
        return availableCopies > 0;
    }

    /** Called when a book is borrowed: stock reduces by one. */
    public void decreaseStock() {
        if (!isAvailable()) {
            throw new BookNotAvailableException("'" + title + "' is currently out of stock.");
        }
        availableCopies--;
    }

    /** Called when a book is returned: stock increases by one. */
    public void increaseStock() {
        if (availableCopies < totalCopies) {
            availableCopies++;
        }
    }

    public String getStockStatus() {
        return availableCopies + " of " + totalCopies + " copies available";
    }
}
