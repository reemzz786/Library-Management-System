package model;

/** Premium member: borrows more books, for a longer period, with a lower fine rate. */
public class PremiumMember extends Member {

    public PremiumMember(String memberId, String name, String email, String phone) {
        super(memberId, name, email, phone);
    }

    @Override
    public String getMemberType() { return "Premium"; }

    @Override
    public int getMaxBooks() { return 6; }

    @Override
    public int getLoanDays() { return 30; }

    @Override
    public double getFinePerDay() { return 2.0; }
}
