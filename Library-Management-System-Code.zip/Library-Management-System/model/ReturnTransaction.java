package model;

import exception.InvalidReturnException;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import util.ValidationUtil;

/** Records the return of a borrowed book and calculates the late fine, if any. */
public class ReturnTransaction {
    private String returnId;
    private BorrowTransaction borrowTransaction;    // link to the original borrow (and its book)
    private LocalDate returnDate;
    private long lateDays;
    private double fine;

    public ReturnTransaction(String returnId, BorrowTransaction borrowTransaction,
                             LocalDate returnDate) {
        if (borrowTransaction.isReturned()) {
            throw new InvalidReturnException("Transaction " + borrowTransaction.getTransactionId()
                    + " has already been returned.");
        }
        if (returnDate.isBefore(borrowTransaction.getBorrowDate())) {
            throw new InvalidReturnException("Return date cannot be before the borrow date ("
                    + borrowTransaction.getBorrowDate().format(ValidationUtil.DATE_FORMAT) + ").");
        }
        this.returnId = returnId;
        this.borrowTransaction = borrowTransaction;
        this.returnDate = returnDate;
        calculateFine();
    }

    public String getReturnId() { return returnId; }
    public BorrowTransaction getBorrowTransaction() { return borrowTransaction; }
    public double getFine() { return fine; }
    public long getLateDays() { return lateDays; }

    /** fine = late days x fine per day of the member (rate differs for Regular / Premium). */
    private void calculateFine() {
        lateDays = Math.max(0, ChronoUnit.DAYS.between(borrowTransaction.getDueDate(), returnDate));
        fine = lateDays * borrowTransaction.getMember().getFinePerDay();
    }

    /** Stock increases immediately, member count reduces, and the receipt is printed. */
    public void execute() {
        borrowTransaction.getBook().increaseStock();
        borrowTransaction.getMember().decrementBorrowed();
        borrowTransaction.markReturned();
        printReceipt();
    }

    public void printReceipt() {
        Member member = borrowTransaction.getMember();
        Book book = borrowTransaction.getBook();
        System.out.println("\n------------ RETURN RECEIPT ------------");
        System.out.println("Return ID      : " + returnId);
        System.out.println("Borrow Txn ID  : " + borrowTransaction.getTransactionId());
        System.out.println("Member         : " + member.getMemberId() + " - " + member.getName()
                + " (" + member.getMemberType() + ")");
        System.out.println("Book           : " + book.getBookId() + " - " + book.getTitle());
        System.out.println("Borrow Date    : "
                + borrowTransaction.getBorrowDate().format(ValidationUtil.DATE_FORMAT));
        System.out.println("Due Date       : "
                + borrowTransaction.getDueDate().format(ValidationUtil.DATE_FORMAT));
        System.out.println("Return Date    : " + returnDate.format(ValidationUtil.DATE_FORMAT));
        if (lateDays > 0) {
            System.out.printf("Late Days      : %d%n", lateDays);
            System.out.printf("Fine           : Rs.%.2f (%d days x Rs.%.2f)%n",
                    fine, lateDays, member.getFinePerDay());
        } else {
            System.out.println("Fine           : Rs.0.00 (returned on time)");
        }
        System.out.println("Updated Stock  : " + book.getStockStatus());
        System.out.println("----------------------------------------\n");
    }
}
