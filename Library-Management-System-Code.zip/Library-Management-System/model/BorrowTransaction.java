package model;

import exception.BorrowLimitExceededException;
import exception.BookNotAvailableException;
import java.time.LocalDate;
import util.ValidationUtil;

/** Records that a member borrowed a book. Linked directly to the Book and Member. */
public class BorrowTransaction {
    private String transactionId;
    private Member member;
    private Book book;
    private LocalDate borrowDate;
    private LocalDate dueDate;
    private boolean returned;

    public BorrowTransaction(String transactionId, Member member, Book book, LocalDate borrowDate) {
        this.transactionId = transactionId;
        this.member = member;
        this.book = book;
        this.borrowDate = borrowDate;
        this.dueDate = borrowDate.plusDays(member.getLoanDays());   // depends on member type
        this.returned = false;
    }

    public String getTransactionId() { return transactionId; }
    public Member getMember() { return member; }
    public Book getBook() { return book; }
    public LocalDate getBorrowDate() { return borrowDate; }
    public LocalDate getDueDate() { return dueDate; }
    public boolean isReturned() { return returned; }
    public void markReturned() { this.returned = true; }

    /** Checks the rules, reduces stock immediately and prints the receipt. */
    public void execute() {
        if (!book.isAvailable()) {
            throw new BookNotAvailableException("'" + book.getTitle()
                    + "' is not available. All copies are borrowed.");
        }
        if (!member.canBorrow()) {
            throw new BorrowLimitExceededException(member.getName() + " has reached the limit of "
                    + member.getMaxBooks() + " books for a " + member.getMemberType() + " member.");
        }
        book.decreaseStock();
        member.incrementBorrowed();
        printReceipt();
    }

    public void printReceipt() {
        System.out.println("\n------------ BORROW RECEIPT ------------");
        System.out.println("Transaction ID : " + transactionId);
        System.out.println("Member         : " + member.getMemberId() + " - " + member.getName()
                + " (" + member.getMemberType() + ")");
        System.out.println("Book           : " + book.getBookId() + " - " + book.getTitle());
        System.out.println("Author         : " + book.getAuthor().getName());
        System.out.println("Borrow Date    : " + borrowDate.format(ValidationUtil.DATE_FORMAT));
        System.out.println("Due Date       : " + dueDate.format(ValidationUtil.DATE_FORMAT)
                + " (" + member.getLoanDays() + " days)");
        System.out.println("Books Held     : " + member.getBorrowedCount()
                + " / " + member.getMaxBooks());
        System.out.println("Updated Stock  : " + book.getStockStatus());
        System.out.println("----------------------------------------\n");
    }
}
